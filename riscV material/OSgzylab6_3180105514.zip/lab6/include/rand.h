#ifndef RAND_H
#define RAND_H

#define SEED 13
unsigned int rand();

#endif