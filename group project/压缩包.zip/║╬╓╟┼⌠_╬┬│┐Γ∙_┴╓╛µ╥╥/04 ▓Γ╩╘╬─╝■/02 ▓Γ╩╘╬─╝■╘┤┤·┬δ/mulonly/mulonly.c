// See LICENSE for license details.

// *************************************************************************
// multiply filter bencmark
// -------------------------------------------------------------------------
//
// This benchmark tests the software multiply implemenation. The
// input data (and reference data) should be generated using the
// multiply_gendata.pl perl script and dumped to a file named
// dataset1.h

#include "util.h"



int multiply( int* addrone, int* addrtwo )
{

 	int result = 0;

	asm volatile(
		".insn r 0x33, 0, 1, %0, %1, %2"
			:"=r"(result)
			:"r"(addrone),"r"(addrtwo)
	);
 
	return result;

}



int main( int argc, char* argv[] )
{
  int a=33,b=21,c;


#if PREALLOCATE
	c=multiply(&a, &b);
#endif

  setStats(1);
  
  c=multiply(&a, &b);

  setStats(0);

  // Check the results
  if(c!=693) return 8;

  return 0;
}
