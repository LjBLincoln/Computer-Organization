// See LICENSE for license details.


#define ROWONE 5
#define ROWTWO 5
#define COLUMNTWO 5

#define ASIZE 25
#define BSIZE 25
#define CSIZE 25

int a[ASIZE]={1,2,3,4,5,
		6,7,8,9,1,
		2,3,4,5,6,
		7,8,9,1,2,
		3,4,5,6,7};

int b[BSIZE]={1,2,3,4,5,
		6,7,8,9,1,
		2,3,4,5,6,
		7,8,9,1,2,
		3,4,5,6,7};

int verify_data[CSIZE] = 
{
    62,    77,    92,    71,    68,
   130,   161,   192,   142,   110,
    81,   101,   121,    96,    89,
    86,   113,   140,   158,   113,
   100,   125,   150,   121,   110
};

