// See LICENSE for license details.

// *************************************************************************
// multiply filter bencmark
// -------------------------------------------------------------------------
//
// This benchmark tests the software multiply implemenation. The
// input data (and reference data) should be generated using the
// multiply_gendata.pl perl script and dumped to a file named
// dataset1.h
#include<stdio.h>
#include "util.h"


//--------------------------------------------------------------------------
// Input/Reference Data

#include "matrix_data.h"

int multiply( int x, int y )
{

 int i;
 int result = 0;

 for (i = 0; i < 32; i++) {
   if ((x & 0x1) == 1)
     result = result + y;
       
   x = x >> 1;
   y = y << 1;
 } 
 
 return result;

}


//--------------------------------------------------------------------------
// Main

int main( int argc, char* argv[] )
{

  int results_data[CSIZE];

	int cij;
	int ii,jj,kk;


#if PREALLOCATE
	for (ii = 0; ii < ROWONE; ii++)
  	for (jj = 0; jj < COLUMNTWO; jj++) {
  		cij = 0;
			for (kk = 0; kk < ROWTWO; kk++)
				cij = cij + multiply(a[ii*ROWTWO + kk], b[kk*COLUMNTWO + jj]);
			results_data[ii*COLUMNTWO + jj] = cij;
		}
#endif

  setStats(1);

	for (ii = 0; ii < ROWONE; ii++)
  	for (jj = 0; jj < COLUMNTWO; jj++) {
  		cij = 0;
			for (kk = 0; kk < ROWTWO; kk++){
				cij = cij + multiply(a[ii*ROWTWO + kk], b[kk*COLUMNTWO + jj]);
			}
				
		results_data[ii*COLUMNTWO + jj] = cij;
		}

  setStats(0);

  // Check the result
  jj=0;
  for (ii=0; ii<CSIZE;ii++){
	  if(results_data[ii]!=verify_data[ii])
	  	jj++;

  }

  return jj;
  //return verify( CSIZE, results_data, verify_data );
}
