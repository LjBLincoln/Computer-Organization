// See LICENSE for license details.

// *************************************************************************
// multiply filter bencmark
// -------------------------------------------------------------------------
//
// This benchmark tests the software multiply implemenation. The
// input data (and reference data) should be generated using the
// multiply_gendata.pl perl script and dumped to a file named
// dataset1.h

#include "util.h"



int multiply( int x, int y )
{

 int i;
 int result = 0;

 for (i = 0; i < 32; i++) {
   if ((x & 0x1) == 1)
     result = result + y;
       
   x = x >> 1;
   y = y << 1;
 } 
 
 return result;

}

int main( int argc, char* argv[] )
{
  int a=33,b=21,c;


#if PREALLOCATE
	c=multiply(a, b);
#endif

  setStats(1);
  
  c=multiply(a, b);

  setStats(0);

  // Check the results
  if(c!=693) return 8;

  return 0;
}
