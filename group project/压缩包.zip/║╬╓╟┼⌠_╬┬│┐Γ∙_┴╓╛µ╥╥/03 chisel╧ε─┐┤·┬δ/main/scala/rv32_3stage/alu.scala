// This is borrowed from rocket, and modified to be hardcoded to 32b.
// I will leave it as an excercise to the reader to make a parameterizable ALU
// that doesn't generate extra hardware for 32b. I also didn't carefully
// consider the function encodings. - Chris
package sodor.stage3

import chisel3._
import chisel3.util._

import sodor.common._
import Constants._

object ALU
{
  // TODO is this the optimal encoding?
  val SZ_ALU_FN = 4
  val ALU_X    = 0.U // TODO use a more optimal decode table, which uses "???" format
  val ALU_ADD  = 0.U
  val ALU_SLL  = 1.U
  val ALU_XOR  = 4.U
  val ALU_OR   = 6.U
  val ALU_AND  = 7.U
  val ALU_SRL  = 5.U
  val ALU_SUB  = 10.U
  val ALU_SRA  = 11.U
//  val ALU_SLT  = 12.U
  val ALU_SLTU = 14.U
  val ALU_COPY1= 8.U
  val ALU_MUL  = 2.U

  def isSub(cmd: UInt) = cmd(3)
//  def isSLTU(cmd: UInt) = cmd(1)
}
import ALU._

class ALUIO(implicit val conf: SodorCoreParams) extends Bundle {
  val fn = Input(UInt(SZ_ALU_FN.W))
  val in2 = Input(UInt(conf.xprlen.W))
  val in1 = Input(UInt(conf.xprlen.W))
  val out = Output(UInt(conf.xprlen.W))
  val adder_out = Output(UInt(conf.xprlen.W))
}

class Multipler extends Module{
  val io = IO(new Bundle{
    val in_1 = Input(UInt(8.W))
    val in_2 = Input(UInt(8.W))
    val product = Output(UInt(16.W))
    val en = Input(Bool())
    val sign = Input(Bool())
  })
  when(!io.en){
    io.product := 0.U
  }.otherwise{
    val abs_1 = Mux(io.in_1(7), ~io.in_1(6,0)+1.U, io.in_1(6,0))
    val abs_2 = Mux(io.in_2(7), ~io.in_2(6,0)+1.U, io.in_2(6,0))
    io.product := Mux(io.sign, 65536.U - abs_1 * abs_2, abs_1 * abs_2 )
  }
}


class ALU(implicit val conf: SodorCoreParams) extends Module
{
  val io = IO(new ALUIO)

  val msb = conf.xprlen-1

  val as_en = Mux(io.fn === ALU_SUB | io.fn === ALU_ADD, 1.U,
                                                          0.U)
  val less_en = Mux( io.fn === ALU_SLTU, 1.U,
                                          0.U)
  val shift_en = Mux(io.fn === ALU_SLL | io.fn === ALU_SRL | io.fn === ALU_SRA, 1.U,
                                                                                      0.U)
  val bitop_en = Mux(io.fn === ALU_AND | io.fn === ALU_OR | io.fn === ALU_XOR | io.fn === ALU_COPY1 | io.fn === ALU_X, 1.U,
                                                                                      0.U)
  val mul_en = Mux(io.fn === ALU_MUL, 1.U,
                                        0.U)

  //ADD, SUB
  val sum = Mux(!as_en, 0.U,
                        io.in1 + Mux(isSub(io.fn), -io.in2, io.in2))

  //SLT, SLTU
  val less = Mux(!less_en.toBool, 0.U,
                                  Mux(io.in1(msb) === io.in2(msb), sum(msb), io.in2(msb)))

  //SLL, SRL, SRA
  val shamt = io.in2(4,0).asUInt
  val shin_r = io.in1(31,0)
  val shin = Mux(io.fn === ALU_SRL || io.fn === ALU_SRA, shin_r,
                                                              Reverse(shin_r))
  val shout_r = Mux(!shift_en.toBool(), 0.U,
                                        (Cat(isSub(io.fn) & shin(msb), shin).asSInt >> shamt)(msb,0))
  val shout_l = Reverse(shout_r)

  //AND, OR, XOR
  val bitop = Mux(!bitop_en.toBool(), 0.U,
                                      Mux(io.fn === ALU_AND, io.in1 & io.in2,
                                      Mux(io.fn === ALU_OR,  io.in1 | io.in2,
                                      Mux(io.fn === ALU_XOR, io.in1 ^ io.in2,
                                                                io.in1))))

  //Mul
  val sign = io.in1(msb) ^ io.in2(msb)
  val multipler = Module(new Multipler)
    multipler.io.in_1 := Cat(io.in1(msb), io.in1(6,0))
    multipler.io.in_2 := Cat(io.in2(msb), io.in2(6,0))
    multipler.io.sign := sign
    multipler.io.en := mul_en

  val product = Mux(sign, Cat(multipler.io.product(15), "hffff".U(16.W), multipler.io.product(14,0)),
                            Cat(multipler.io.product(15), 0.U(16.W), multipler.io.product(14,0)))

  val out = Mux(io.fn === ALU_ADD || io.fn === ALU_SUB, sum,
              Mux(io.fn === ALU_MUL, product,
                Mux(io.fn === ALU_SLTU, less,
                  Mux(io.fn === ALU_SRL || io.fn === ALU_SRA, shout_r,
                    Mux(io.fn === ALU_SLL, shout_l,
                      bitop)))))
  io.out := out(31,0).asUInt()
  io.adder_out := sum
}
