package multiply

import chisel3._
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}

/**
 * @author BrineNas
 * @version 2021-06-12-12:10
 */
class SMul extends Module{
  val io = IO(new Bundle{
    val in_1 = Input(UInt(8.W))
    val in_2 = Input(UInt(8.W))
    val product = Output(UInt(16.W))

  })
  val sign = (io.in_1(7) ^ io.in_2(7))
  val abs_1 = Mux(io.in_1(7), ~io.in_1(6,0)+1.U, io.in_1(6,0))
  val abs_2 = Mux(io.in_2(7), ~io.in_2(6,0)+1.U, io.in_2(6,0))
  io.product := Mux(sign, 65536.U - abs_1 * abs_2, abs_1 * abs_2 )
}


class SMulTests(c: SMul) extends PeekPokeTester(c){
  var a = 5.U
  var b = 10.U

  poke(c.io.in_1, a)
  poke(c.io.in_2, b)
  expect(c.io.product, 50.U)

  step(1)
  a = 5.U
  b = 246.U         // =-10.U = ~10.U + 1.U
  var out =65486.U(16.W)
  poke(c.io.in_1, a)
  poke(c.io.in_2, b)
  expect(c.io.product, out)
  step(1)

  a = 50.U
  b = "hce".U         // =-50.U = ~50.U + 1.U = b11001110
  out =63036.U(16.W)  // =-2500.U
  poke(c.io.in_1, a)
  poke(c.io.in_2, b)
  expect(c.io.product, out)
}
class MultiplerTester extends ChiselFlatSpec  {
  behavior of "Multipler"
  backends foreach {backend =>
    it should s"correctly mul randomly generated numbers $backend" in {
      Driver(() => new SMul, backend)(c => new SMulTests(c)) should be (true)
    }
  }
}