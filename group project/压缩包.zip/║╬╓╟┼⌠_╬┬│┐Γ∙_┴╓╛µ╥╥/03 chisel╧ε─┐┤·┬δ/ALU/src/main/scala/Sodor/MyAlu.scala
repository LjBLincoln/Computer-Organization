package Sodor

/**
 * @author BrineNas
 * @version 2021-06-12-14:19
 */

import chisel3._
import chisel3.util.{Cat, Reverse}
import Common.SodorConfiguration
import chisel3.iotesters.{ChiselFlatSpec, Driver, PeekPokeTester}

object MyAlu{
  val SZ_ALU_FN = 4
  val ALU_X: UInt = 0.U   //0b0000
  val ALU_ADD: UInt = 0.U   //0b0000
  val ALU_SLL: UInt = 1.U   //0b0001
  val ALU_XOR: UInt = 4.U   //0b0100
  val ALU_OR: UInt = 6.U   //0b0110
  val ALU_AND: UInt = 7.U   //0b0111
  val ALU_SRL: UInt = 5.U   //0b0101
  val ALU_SUB: UInt = 10.U  //0b1010
  val ALU_SRA: UInt = 11.U  //0b1011
  val ALU_SLT: UInt = 12.U  //0b1100
  val ALU_SLTU: UInt = 14.U  //0b1110
  val ALU_COPY1: UInt = 8.U   //0b1000
  val ALU_MUL: UInt = 2.U   //0b0010

  def isSub(cmd: UInt): Bool = cmd(3)
  def isSLTU(cmd: UInt): Bool = cmd(1)
}
import MyAlu._

class MyAluIO(implicit val conf: SodorConfiguration) extends Bundle {
  val func = Input(UInt(SZ_ALU_FN.W))
  val in_1 = Input(SInt(conf.xprlen.W))
  val in_2 = Input(SInt(conf.xprlen.W))
  val out = Output(SInt(conf.xprlen.W))
}

class AddSub extends Module{
  val io = IO(new Bundle{
    val a = Input(SInt(24.W))
    val b = Input(SInt(24.W))
    val c = Output(SInt(24.W))
    val en = Input(Bool())
    val func_as = Input(UInt(1.W))
  })
  io.c := Mux(!io.en, 0.S,
                    io.a + Mux(io.func_as === 1.U, -io.b, io.b))
}

class Multipler extends Module{
  val io = IO(new Bundle{
    val in_1 = Input(SInt(8.W))
    val in_2 = Input(SInt(8.W))
    val product = Output(SInt(16.W))
    val en = Input(Bool())
  })
  io.product := Mux(!io.en, 0.S,
                            io.in_1 * io.in_2)
}

class MyAluTests(c: MyAlu) extends PeekPokeTester(c){
  var in_1 = 5.S(32.W)
  var in_2 = 10.S(32.W)
  var func = ALU_ADD

  poke(c.io.func, func)
  poke(c.io.in_1, in_1)
  poke(c.io.in_2, in_2)
  expect(c.io.out, 15.S)
  step(1)
}
object Sodor {
  implicit val conf = new SodorConfiguration
}

class MyAluTester extends ChiselFlatSpec  {
  import Sodor._
  behavior of "MyAlu"
  backends foreach {backend =>
    it should s"correctly mul randomly generated numbers $backend" in {
      Driver(() => new MyAlu, backend)(c => new MyAluTests(c)) should be (true)
    }
  }
}

class MyAlu(implicit val conf: SodorConfiguration) extends Module{
  val io = IO(new MyAluIO())

  val msb = conf.xprlen-1

  val as_en = Mux(io.func === ALU_SUB | io.func === ALU_ADD, 1.U,
                                                              0.U)
  val less_en = Mux(io.func === ALU_SLT | io.func === ALU_SLTU, 1.U,
                                                                0.U)
  val shift_en = Mux(io.func === ALU_SLL | io.func === ALU_SRL | io.func === ALU_SRA, 1.U,
                                                                                      0.U)
  val bitop_en = Mux(io.func === ALU_AND | io.func === ALU_OR | io.func === ALU_XOR, 1.U,
                                                                                      0.U)
  val mul_en = Mux(io.func === ALU_MUL, 1.U,
                                        0.U)

  //ADD, SUB
  val addsuber = Module(new AddSub())

    addsuber.io.a := Cat(io.in_1(msb), io.in_1(22,0))
    addsuber.io.b := Cat(io.in_1(msb), io.in_1(22,0))
    addsuber.io.func_as := io.func(3)
    addsuber.io.en := as_en

  val sum = Cat(addsuber.io.c(23), 0.S(8.W), addsuber.io.c(22,0))

  //SLT, SLTU
  val less = Mux(!less_en.toBool, 0.S,
                                  Mux(io.in_1(msb) === io.in_2(msb), sum(msb),
                                  Mux(isSLTU(io.func), io.in_2(msb), io.in_1(msb)))
                                  )

  //SLL, SRL, SRA
  val shift = io.in_2(4,0).asUInt()
  val shin_r = io.in_1(31,0)
  val shin = Mux(io.func === ALU_SRL || io.func === ALU_SRA, shin_r,
                                                              Reverse(shin_r))
  val shout_r = Mux(!shift_en.toBool(), 0.U,
                                        (Cat(isSub(io.func) & shin(msb), shin).asSInt() >> shift)(msb,0))
  val shout_l = Reverse(shout_r)

  //AND, OR, XOR
  val bitop = Mux(!bitop_en.toBool(), 0.U,
                                      Mux(io.func === ALU_AND, io.in_1 & io.in_2,
                                      Mux(io.func === ALU_OR,  io.in_1 | io.in_2,
                                      Mux(io.func === ALU_XOR, io.in_1 ^ io.in_2,
                                                                io.in_1))))

  //Mul
  val multipler = Module(new Multipler)
    multipler.io.in_1 := Cat(io.in_1(msb), io.in_1(6,0))
    multipler.io.in_2 := Cat(io.in_1(msb), io.in_1(6,0))
    multipler.io.en := mul_en

  val product =
    Cat(multipler.io.product(15), 0.S(16.W), multipler.io.product(14,0))

}
//class AddSubTests(c: AddSub) extends PeekPokeTester(c){
//  var a: SInt = 5.S
//  var b: SInt = 10.S
//  var func = 0.U
//  poke(c.io.func_as, func)
//  poke(c.io.a, a)
//  poke(c.io.b, b)
//  poke(c.io.en, false)
//  expect(c.io.c, 0.S)
//  step(1)
//  poke(c.io.en, value = true)
//  expect(c.io.c, 15.S)
//  step(1)
//  func = 1.U
//  poke(c.io.func_as, func)
//  expect(c.io.c, -5.S)
//}
//class AddSubTester extends ChiselFlatSpec  {
//  behavior of "AddSub"
//  backends foreach {backend =>
//    it should s"correctly mul randomly generated numbers $backend" in {
//      Driver(() => new AddSub, backend)(c => new AddSubTests(c)) should be (true)
//    }
//  }
//}

