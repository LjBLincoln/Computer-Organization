package multiply
/**
 * @author BrineNas
 * @version 2021-06-11-19:13
 */
import chisel3._
import chisel3.iotesters.{ChiselFlatSpec, Driver, PeekPokeTester}

class Mul extends Module{
  val io = IO(new Bundle{
    val in_1 = Input(UInt(8.W))
    val in_2 = Input(UInt(8.W))
    val product = Output(UInt(16.W))
  })
    io.product := io.in_1 * io.in_2;
}

class MulTester(c: Mul) extends PeekPokeTester(c){
  for (t <- 0 until 10) {
    val mul_a = rnd.nextInt(255)
    val mul_b = rnd.nextInt(255)
    poke(c.io.in_1,  mul_a)
    poke(c.io.in_2,  mul_b)
    val mul_c = mul_a * mul_b
    expect(c.io.product,  mul_c)
  }
}


class MulTest extends ChiselFlatSpec  {
  behavior of "Mul"
  backends foreach {backend =>
    it should s"correctly mul randomly generated numbers $backend" in {
      Driver(() => new Mul, backend)(c => new MulTester(c)) should be (true)
    }
  }
}
