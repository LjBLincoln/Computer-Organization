package Common
/**
 * @author BrineNas
 * @version 2021-06-12-14:19
 */
{

  case class SodorConfiguration()
  {
    val xprlen = 32
  }


}
