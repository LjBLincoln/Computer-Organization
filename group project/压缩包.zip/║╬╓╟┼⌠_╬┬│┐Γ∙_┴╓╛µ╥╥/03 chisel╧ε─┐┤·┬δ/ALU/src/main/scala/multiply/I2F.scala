package multiply

import chisel3._
import chisel3.experimental.RawModule
import chisel3.util._
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}


/**
 * @author BrineNas
 * @version 2021-06-12-10:14
 */
class I2F extends Module{
  val io = IO(new Bundle() {
    val inter = Input(UInt(24.W))
    val float = Output(UInt(16.W))
  })
  val s = io.inter(23)
  when(io.inter(22) === 1.U){
    io.float := 8.U
  }.elsewhen(io.inter(21) === 1.U){
    io.float := 4.U
  }.elsewhen(io.inter(20) === 1.U){
    io.float := 2.U
  }.elsewhen(io.inter(19) === 1.U){
    io.float := 1.U
  }.otherwise{
    io.float := 0.U
  }
}

class I2FTests(c: I2F) extends PeekPokeTester(c) {
  val inte = 15.U
  poke(c.io.inter,  inte)
  expect(c.io.float, 8)
}

class I2FTester extends ChiselFlatSpec  {
  behavior of "I2F"
  backends foreach {backend =>
    it should s"correctly mul randomly generated numbers $backend" in {
      Driver(() => new I2F, backend)(c => new I2FTests(c)) should be (true)
    }
  }
}